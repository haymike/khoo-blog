---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
thumbnail: "path/thumbnail.jpg"
draft: true
---
