const $ = window.jQuery
require('zoom.js')
require('./zoom/transition.js')

$(() => {
  // Add JavaScript Code
})
